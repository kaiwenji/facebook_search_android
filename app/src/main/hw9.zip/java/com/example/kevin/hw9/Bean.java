package com.example.kevin.hw9;

import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * Created by kevin on 2017/4/14.
 */

public class Bean {
    List<Cat> name;


}
